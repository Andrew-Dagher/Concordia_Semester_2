package InnovationLab;

public class Employee {

	protected  String Skills;
	protected  double Salary;
	protected  double ESOP;
	
	public Employee(){
		Skills = "Java, Pyhthon";
		Salary = 40000;
		ESOP = 2;
	}
	
	public String getSkills() {
		return Skills;
	}
	
	public double getSalary() {
		return Salary;
	}
	
	public double getESOP() {
		return ESOP;
	}
	
	
	
	
	
	
	
	
	
}
