package Technology;

import InnovationLab.Employee;

public class driver {
	
	public static void main(String[] args) {
		
	
	Employee Emp = new Employee();
	SoftwareDeveloper D = new SoftwareDeveloper();
	DevOps DO = new DevOps();
	
	Employee[] array = new Employee[3];
	
	array[0]=Emp;
	array[1]=D;
	array[2]=DO;
	
	}
}