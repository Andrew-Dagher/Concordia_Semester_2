package Lab9;

public class Driver {

	public static void main(String[] args) {
		FibonacciSequence f = new FibonacciSequence();
		
	System.out.println("at the 4th term, we get: "+f.getFib(4));
	System.out.println();
	System.out.println(f.sumFib(1));
	System.out.println(f.sumFib(2));
	System.out.println(f.sumFib(3));
	System.out.println(f.sumFib(4));
	System.out.println(f.sumFib(5));
	System.out.println(f.sumFib(6));
	System.out.println(f.sumFib(7));
	System.out.println(f.sumFib(8));
	System.out.println(f.sumFib(9));
	System.out.println(f.sumFib(10));



	}

}
