package lab10;

public interface Comparison {

	public boolean Top_rank(Object b); 
	public boolean Low_rank(Object b); 
	
	
	
	
	
}
