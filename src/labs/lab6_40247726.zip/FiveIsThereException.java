package labs;

public class FiveIsThereException extends Exception {

	
	public FiveIsThereException() {
		
	}
	public FiveIsThereException(String exception) {
		System.out.println(exception);
		
	}

}
