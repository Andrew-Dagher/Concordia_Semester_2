package labs;

public class ZeroIsThereException extends Exception{

	public ZeroIsThereException() {
		
	}
	public ZeroIsThereException(String exception) {
		System.out.println(exception);
	}
	
}
